#include<stdio.h>
int main(){

int a =15;
printf("%d\n",++a);
printf("%d\n",a++);
printf("%d\n",--a);
printf("%d",a--);









return 0;
}

